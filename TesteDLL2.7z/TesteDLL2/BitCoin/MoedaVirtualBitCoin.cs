﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Remoting.Messaging;
using System.Text;
using System.Threading.Tasks;
using Banco;

namespace BitCoin
{
    public class MoedaVirtualBitCoin
    {
        public double ValorBitCoin(DateTime dt)
        {
            double valor = 0.0;
            BaseDados Banco = new BaseDados();
            int TipoMoeda = 1;
            Banco.ValorMoeda(TipoMoeda, dt, ref valor);
            return valor;
        }
    }
}
