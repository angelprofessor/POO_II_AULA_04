﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Banco
{
    public class BaseDados
    {
        public bool ValorMoeda(int TipoMoeda, DateTime dt, ref Double valor)
        {
            bool ret = false;

            switch(TipoMoeda)
            {
                case 1:
                    valor = 33.89;
                    break;
                case 2:
                    valor = 12.46;
                    break;
                default:
                    break;
            }

            return ret;
        }
    }
}
