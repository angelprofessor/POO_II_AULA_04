﻿
using BitCoin;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TesteDLL2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            MoedaVirtualBitCoin biCoin = new MoedaVirtualBitCoin();
            DateTime dt = DateTime.Now;
            double Valor = biCoin.ValorBitCoin(dt);
            textBox1.Text = Valor.ToString();
        }
    }
}
